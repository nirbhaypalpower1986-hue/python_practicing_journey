a = input("Enter the username: ")
if len(a)<10:
    print("The username must contain 10 charaters.")
else:
    print("The username is valid.")    