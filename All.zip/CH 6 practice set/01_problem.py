a=int(input("Enter a number: "))
b=int(input("Enter a number: "))
c=int(input("Enter a number: "))
d=int(input("Enter a number: "))

if a>b and a>c and a>d:
    print(f"The number a is greatest.")
elif b>a and b>c and b>d:
    print(f"The number b is greatest.")
elif c>a and c>b and c>d:
    print(f"The number c is greatest.")
elif a==b==c==d:
    print("All numbers are equal.")
else:
    print(f"The number d is greatest.")