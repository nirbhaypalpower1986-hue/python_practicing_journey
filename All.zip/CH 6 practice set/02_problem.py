marks1=int(input("Enter marks of chem:"))
marks2=int(input("Enter marks of math:"))
marks3=int(input("Enter marks of phy:"))

#check for total percentage

total_marks=(marks1+marks2+marks3)*100/300
if marks1>=33 and marks2>=33 and marks3>=33:
    print(f"you are pass with {total_marks} % 🎉🎉🎉")
elif marks1 > 100 or marks2 > 100 or marks3 > 100 or marks1<0 or marks2<0 or marks3<0:
    print("Marks should not be greater than 100 and not less than 0")
else:
    if marks1<33:
        print(f"As you fail in chemistry with {marks1} marks.")
    if marks2<33:
        print(f"As you fail in mathematics with {marks2} marks.")
    if marks3<33:
        print(f"As you fail in physics with {marks3}")
    
    print("You are fail!!!")
    print("Better luck next time👍")