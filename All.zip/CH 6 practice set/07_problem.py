a=("Abhay").lower()
b = input("Enter the text: ").lower()
if a in b :
    print("This text is related to Abhay")
else:
    print("This text is not talking about Abhay")    
          