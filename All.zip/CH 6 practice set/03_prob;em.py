a = input("Enter the text here : ").lower()

if "make a lot of money" in a or "buy now" in a or "subscribe this" in a or "click this" in a:
    print("This is a scam.⚠️")

else:
    print("This is probably safe. please make sure you are on trusted website. ")    