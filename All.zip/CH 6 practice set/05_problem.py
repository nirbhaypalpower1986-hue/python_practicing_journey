a = ["Abhay","Nirbhay","Ritesh","Rohan","Pandey","Amit"]

b = input("Enter the name: ")

if b in a:
    #print("This name is present in the entry lists.")
    print(f"Heartly welcomes MR.{b}")
else:
    print("Your name is not present in the lists.")
    print("You can't enter.")