marks = int(input("Enter you marks here: "))
if marks>100 or marks<0:
    print("Invalid marks")

elif marks>=90:
    print("EX grade")
elif marks>=80:
    print("A grade")
elif marks>=70:
    print("B grade")
elif marks>=60:
    print("C grade")
elif marks>=50:  
    print("D grade ")
elif marks<50:
    print("fail")      