import pyttsx3
engine = pyttsx3.init()
engine.say("bees rupaye ki sabji ke sath dhaniya mircha free")
engine.runAndWait()
 
