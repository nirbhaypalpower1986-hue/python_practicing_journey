import os

path = 'CH 1'   # Replace with your directory path

contents = os.listdir(path)

print("Directory contents:")
for item in contents:
    print(item)