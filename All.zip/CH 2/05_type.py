a="abhay" #string
b=10 #integer
c=3.14 #float
d=True #boolean

print(type(a))
print(type(b))          
print(type(c))
print(type(d))

