a = 2
aaa = 55
harrry = 67 
_sameer = 45
# @samer = 45678
# 1abhay = 1254