# a=input("Enter your name: ")
# print("have a great day ", a)


a=int(input("enter number 1: "))
b=int(input("enter number 2: "))

# print("number 1 is ",a)
# print("number 2 is ",b)

print(f"the sum of number {a} and {b} is ",a+b)