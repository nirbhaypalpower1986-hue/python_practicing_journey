# Arthematic operators

a=34
b=4
c=a+b
print(c)

# Assignment operators

s=4-3 # assign 4-3 to s 
print(s)
d=5
d+=6 # increment the value of d by 6 and assigne it to d
print(d)

#comparison operators

s=3
j=s>=5 # check if s is greater than or equal to 5
print(j)

# logical operators 
# e = True or False

# print(e) 

# truth table of 'or'

print("true or true is ", True or True)
print("true or false is ", True or False)
print("false or true is ", False or True)
print("false or false is ", False or False)

# truth table of 'and'

print("true and true is ", True and True)
print("true and false is ", True and False)
print("false and true is ", False and True)
print("false and false is ", False and False)

