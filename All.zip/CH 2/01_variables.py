a=1

b=3

print(a+b) 
# ye sab ka mtlb hai ki kisi container ke andar humne kya store kiya hai 