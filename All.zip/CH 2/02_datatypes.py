a=1   #a is as integer data type
b=5.22 # b is a floatingpoint number
c="Hello World" # c is a string data type
d=True # d is a boolean data type
e=False # e is also a boolean data type
f=None # f is a NoneType data type
