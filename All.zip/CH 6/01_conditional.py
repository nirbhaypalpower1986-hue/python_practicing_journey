a=int(input("Enter a number: "))

if a == 0:
    print("The number is zero and even.")

elif a > 0:
    if a%2==0:
        print("The number is positive even")
    else:
         print("The number is positive and odd.") 

else:
    if a%2==0:
        print("The number is negative and even.")
    else:
        print("The number is negative and odd.")