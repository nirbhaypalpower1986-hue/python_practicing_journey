a=int(input("Enter a number: "))
      
if a%2==0:                     # this is an independent if statement 
    print("The number is even.")
else:
    print("The number is odd.")


if a>0:#This is an another independent if statement
    print("The number is positive.")
else:
    print("The number is negative.")