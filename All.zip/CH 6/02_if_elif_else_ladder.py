a=int(input("Enter a number: "))

#if ellif and else ladders are used to
#check multiple conditions in a 
#program. The program checks if the 
#number is zero, positive, or 
#negative and then further checks 
#if it is even or odd.
if a == 0:
    print("The number is zero and even.")

elif a > 0:
    if a%2==0:
        print("The number is positive even")
    else:
         print("The number is positive and odd.") 

else:
    if a%2==0:
        print("The number is negative and even.")
    else:
        print("The number is negative and odd.")