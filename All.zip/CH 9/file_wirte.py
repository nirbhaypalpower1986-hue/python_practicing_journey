s = "Abhay is a good boy. He is so dumb also."

f = open("file.txt","w")
f.write(s)
f.close()

f = open("file.txt", "rb")#for getting the file translate in binary 

d = f.readlines()
f.close()

for line in d:
    print(' '.join(format(byte, '08b') for byte in line))
