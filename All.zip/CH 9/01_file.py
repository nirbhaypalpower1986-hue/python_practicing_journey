'''
a = "a very long email"

e =[] # here data is temperarly stored and if its close it is not stored
ram me store hota hai ye sab and then delete
file me ham data store bhi kar sakte hai
'''

f = open("file.txt")
s = f.read()
print(s)
f.close


 