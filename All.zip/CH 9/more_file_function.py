f = open("file.txt")

# s=f.readlines()# read all lines at once and return list of lines

s=f.readline()#this read the first line of the file
print(s,type(s))#return strings
s1 = f.readline()#second time this read the second line of the file
print(s1)
# and it continues till the last line reaches


f.close()