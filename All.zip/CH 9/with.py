f = open("file.txt")
print(f.read())
f.close()

# The same task can be done by using with statement

with open("file.txt") as f:
    print(f.read())

#automatically closes file after exiting from the identation of with 
