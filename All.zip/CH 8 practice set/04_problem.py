'''
sum(1) = 1
sum(2) = 1 + 2 
sum(3) = 1 + 2 + 3
sum(4) = 1 + 2 + 3 + 4
sum(5) = 1 + 2 + 3 + 4 + 5  

sum(n) = 1 + 2 + 3 + ... + n
sum(n) = n + sum(n-1)
'''
n = int(input("Enter a number of which you want to sum of natural numbers: "))
def sum(n):
    if n == 1:
        return 1
    return sum(n-1) + n 
print(sum(n))

