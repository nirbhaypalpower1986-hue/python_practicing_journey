l = ["Abhay","Rohit","Nirbhay","Akash","zx"]

def remove(word,l):
    for item in l:
        l.remove(word)
        return l
remove("zx")
print(l)


