'''
1 = 0+0
2 = 1+0
3 = 1+0
4 = 1+1
5 = 2+1
6 = 3+2
7 = 5+3
8 = 8+5

fibonacci = n+fibonacci(n-1)
'''

def fibonacci(n):
    if n == 1:
        return 0
    elif n == 2:
        return 1
    else:
        return fibonacci(n-1)+fibonacci(n-2)

n = int(input("Enter the value of n: "))
print(fibonacci(n))