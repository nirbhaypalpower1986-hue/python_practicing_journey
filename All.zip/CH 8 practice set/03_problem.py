print("a")
print("b")
print("c",end="")#stop print function 
print("d",end="")#to print a new line

