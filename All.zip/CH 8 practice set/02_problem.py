# celsius = int(input("Enter temperature in Celsius: "))
a = float(input("Enter temperature in Celsius: "))

def celsius_to_fahrenheit(a): 
    fahrenheit = (a * 9/5) + 32
    return fahrenheit

print(celsius_to_fahrenheit(a))
