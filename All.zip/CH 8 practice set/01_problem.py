def greatest(a):
    if a==b==c:
        return "All numbers are equal"
    elif a>=b and a>=c:
        return a
    elif b>=a and b>=c:
        return b
    else:
        return c     


a = int(input("Enter the number a:"))     
b = int(input("Enter the number b:"))
c = int(input("Enter the number c:"))

print(greatest(a))