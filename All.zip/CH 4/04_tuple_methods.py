a=(1,3,5,9.9,"abhay","nirbhay", True)
print(a)
no=a.count(9.9)#it counts how many times the given value is in your tuple
print(no)

i = a.index(9.9)
print(i)

