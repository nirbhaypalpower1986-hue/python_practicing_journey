a=(1,3,5,9.9,"abhay","nirbhay", True)
print(type(a))
print(a)

b = () #empty tuple
c=(1,)#single tuple

# a[0]=45 we cannot change it