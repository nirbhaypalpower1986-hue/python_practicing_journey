a = [1, "Abhay", 3.98, True, "Nirbhay"] # list are mutable
print(a)

print(a[0])# prints the first element of list a

a[0]="Masum"# at index 1 "1" is replace by "Masum"

print(a)

print(a[1:5])