a=["abhay",True,89,3,98,8.9,]
a.append("Nirbhay")#isko list ke end me add kar do
a.insert(3,"ABHAY")#isko list me add kar do at index 3
print(a)

l1 = [1,34,85,90,32,23,45,51,50,19,11]# 90 at index 3
# l1.sort()
# l1.reverse()
# l1.pop(3)#remove kar do index 3 vali value ko
print(l1.pop(3))#ye ye bhi batayega ki kis value ko  remove kiya hai
print(l1)


