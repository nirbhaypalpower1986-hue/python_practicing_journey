a = "abhay" 

print(a[0:3])

print(a[-4:-1]) #convert this into positive indexing and then print it
print(a[1:4])

print(a[0:4]) # is same as print(a[0:4])
print(a[1:]) # is same as print(a[1:5]) 
