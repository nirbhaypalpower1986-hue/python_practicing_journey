a = "abahy"

print(len(a)) # length of the string
print(a.endswith("hy"))
print(a.endswith("bh"))
print(a.startswith("ab"))
print(a.capitalize()) # capitalize the first letter of the string
print(a.upper()) # convert the string to uppercase


b="abhay is good."
print(b.title()) # capitalize the first letter of each word in the string

print(b.replce("good", "very bad")) # replace the word "good" with "very bad" in the string

