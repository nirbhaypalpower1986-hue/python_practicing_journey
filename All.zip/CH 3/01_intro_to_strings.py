a="harry" # h at 0, a at 1, r at 2, r at 3, y at 4
s=len(a)
print(s)

nameshort=a[0:3] # start from index to index 3 but 3 is not included 
print(nameshort)

character1=a[0] # index 0 is h
print(character1)

# negative indexing
f= "abhay" # a at -5, b at -4, h at -3, a at -2, y at -1