# skip Value  

a = "12344567890"

print(a[0:9:2]) # start from index 0 to index 9 but 9 is not included and skip value is 2
