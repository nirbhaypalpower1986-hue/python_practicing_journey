a = "abhay is a good boy \n but  not a bad \"boy\""

print(a)