s = set()
s.add(20)
s.add(20.0)
s.add('20') # length of s after these operations?

print(s)
print(len(s))# "20", "20.0" are counted a single element in the set because they are considered equal in Python. Therefore, the length of s will be 2
 # 1=1.0