a={}

f=input("Enter the freinds name: ")
l=input("Enter the language: ")
a.update({f:l})

f=input("Enter the freinds name: ")
l=input("Enter the language: ")
a.update({f:l})

f=input("Enter the freinds name: ")
l=input("Enter the language: ")
a.update({f:l})

f=input("Enter the freinds name: ")
l=input("Enter the language: ")
a.update({f:l})

# if a key upfate twice then the value will be updated to the latest value
# problem 7 is solved by the uper line

print(a)