words = {"Apple": "seb",
         "Cat": "billi",
         "Dog": "kutta",
         "Help": "madad"}
a = input("enter the word you want to translate: ")
print(words[a])