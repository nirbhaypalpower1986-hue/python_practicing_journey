# If the language of the two different students
#  are same then , nothing 
# happen both students 
# got the same language. 
# Means it is possible.

#But if the name and the
# lanuguage of both students 
# are same then only one is
# writing in the dictonaries.
