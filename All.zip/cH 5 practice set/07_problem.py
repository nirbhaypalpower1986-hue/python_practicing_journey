# If the name of the two studnets
# are same in problem 6, then the 
# latest information will take place. 
# So it was updated.