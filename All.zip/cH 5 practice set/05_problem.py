s={}# it a dictionary
print(type(s))