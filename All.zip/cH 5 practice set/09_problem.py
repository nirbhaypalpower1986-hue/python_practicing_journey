s = {8, 7, 12, "Harry", [1,3]}

#can we change the value of a list inside a set?
#set elemetns are not mutable
#set can't be indexed or sliced 
