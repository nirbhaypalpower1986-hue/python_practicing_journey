import pyjokes
# for printing jokes .....
joke = pyjokes.get_joke()
print(joke)
'so thanks that '
'wa my program for printing jokes '
'it as for printing jokes'

# thanks 