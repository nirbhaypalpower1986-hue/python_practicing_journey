class enterprenuer:
    # name = "Abhay"
    passion = "Money making"
    net_worth = 100000000 

a = enterprenuer()
a.name = "Abhay"
print(a.name, a.passion, a.net_worth)
 
b = enterprenuer()
b.name = "Rohan"
print(b.name,b.passion,b.net_worth)

    