a=int(input("enter the number : "))
print(f"the square of num {a} is {a**2}")
# print(f"the square of num {a} is {a^2}") it is not correct to find the square