a=int(input("enter number a :"))
b=int(input("enter number b :"))
print("a is grater tha b is ",a>b)