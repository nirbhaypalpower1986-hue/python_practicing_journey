a=int(input("enter first number : "))

b=int(input("enter second number : "))

print(f"the sum of {a} and {b} is : {a+b}")