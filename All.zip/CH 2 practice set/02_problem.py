a=int(input("enter the divisor: "))

b=int(input("enter the dividend: "))

print(f"the remainder when {a} is divided by {b} is : {a%b}")