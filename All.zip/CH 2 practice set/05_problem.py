a=int(input("enter number a :"))
b=int(input("enter number b :"))
print(f"the avg of a and b is : {(a+b)/2}") 