a=input("enter: ")#always takes input as string
 
# print(f"the type of the input is : {type(a)}")