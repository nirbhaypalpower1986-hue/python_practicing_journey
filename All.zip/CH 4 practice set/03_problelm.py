a = (1,"abhay", True, 5.4)

a[0]=5 # jence tuple can't be changed it is imutable