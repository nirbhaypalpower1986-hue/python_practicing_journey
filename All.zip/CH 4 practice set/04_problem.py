a=[2,3,34,3333]

print(sum(a))