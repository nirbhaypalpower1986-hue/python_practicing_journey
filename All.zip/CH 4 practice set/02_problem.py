Marks = []

f1 = int(input("Enter marks of S1 : "))
f2 = int(input("Enter marks of S2 : "))
f3 = int(input("Enter marks of S3 : "))
f4 = int(input("Enter marks of S4 : "))
f5 = int(input("Enter marks of S5 : "))
f6 = int(input("Enter marks of S6 : "))

Marks.append(f1)
Marks.append(f2)
Marks.append(f3)
Marks.append(f4)
Marks.append(f5)
Marks.append(f6)

Marks.sort()# it does not return anything 
print(Marks)





