Fruits = []


f1 = input("Enter Fruit name : ")
f2 = input("Enter Fruit name : ")
f3 = input("Enter Fruit name : ")
f4 = input("Enter Fruit name : ")
f5 = input("Enter Fruit name : ")
f6 = input("Enter Fruit name : ")
f7 = input("Enter Fruit name : ")

Fruits.append(f1)
Fruits.append(f2)
Fruits.append(f3)
Fruits.append(f4)
Fruits.append(f5)
Fruits.append(f6)
Fruits.append(f7)

print(Fruits)





