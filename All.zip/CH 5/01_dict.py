a = {
    "Abhay" : 100,
    "Nirbhay" : 99,
    "Rishabh" : 98,
    "Satyam" : 97,
}

print(a)

b = a["Abhay"]
print(b)

# print(type(a))
# print(a[0]) it will give error because dictionary is not indexed

# m=[["Abhay",100],["Nirbhay",200]]