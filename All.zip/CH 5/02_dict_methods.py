a = {
    "Abhay" : 100,
    "Nirbhay" : 99,
    "Rishabh" : 98,
    "Satyam" : 97,
    0 : "Rohan"
}

# print(a.items())

# print(a.keys())

# print(a.values())

# a.update({"Abhay": 101, "tanush":99}) # update the value of a and add tanush in dict a 

# print(a)

# print(a.get("Abhay2")) # it will return None because Abhay2 is not present in dict a
# print(a["Abhay2"])# it will give error because Abhay2 is not present in dict a