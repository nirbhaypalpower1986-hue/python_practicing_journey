#thse are unindexed data types
#order doesn't matter in sets

a={1,2,3,4,5,6,7,8,9,10}
print(a)
a.add(11) # add 11 in set a at the end
print(a)

print(len(a))# to pritn length of set a

a.remove(11)# to romove 11 form set a 

a.pop