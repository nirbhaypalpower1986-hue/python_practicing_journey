s={}#empty dictionary
a={1,2,3,4,5} #set
e=set() #empty set, don't use e={} bcz it will create empty dictionary