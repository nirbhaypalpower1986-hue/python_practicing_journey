#snake water gun game

import random

print("Snake, Water, Gun game begins.")

s = "Snake"
w = "Water"
g = "Gun"

l = ["s","g","w"]

while True:
    print("STARTING THE GAME\nSnake=s\nWater=w\nGun=g\nSelect from these.")
    print("If you want to exit the game, type 'no'")
    computer = random.choice(l)
    you = input("Enter your choice: ")
    if you == computer:
        print(f"You chose {you} and computer chose {computer}")
        print("It's a tie!")
    elif you not in ("no","s","g","w"):
        print("Invalid input. Please select from the given options.") 
    elif you == "no":
        print("Now exiting the game.")
        break
    elif you == "s" and computer == "w":
        print(f"You chose {s} and computer chose {w}")
        print("YOU WON!!!")
    elif you == "s" and computer == "g":
        print(f"You chose {s} and computer chose {g}")
        print("YOU LOSE!!!")
    elif you == "w" and computer == "s":
        print(f"You chose {w} and computer chose {s}")
        print("YOU LOSE!!!")
    elif you == "w" and computer == "g":
        print(f"You chose {w} and computer chose {g}")
        print("YOU WON!!!")
    elif you == "g" and computer == "s":
        print(f"You chose {g} and computer chose {s}")
        print("YOU WON!!!")
    elif you == "g" and computer == "w":
        print(f"You chose {g} and computer chose {w}")
        print("YOU LOSE!!!")

    print("Thanks for playing!")
    print('\n')  
    print("Do you want to play again? (yes/no): ")

    play_again = input("IF you want to play again, type 'y' or 'yes', else type 'no' or 'n' for exiting: ")
    if play_again not in ("y","yes","n","no"):
        print("Invalid input. Please select from the given options.")
    else:
        if play_again == "y" or play_again == "yes":
            continue
        elif play_again == "n" or play_again == "no":
            print("Now exiting the game.")
            break    
