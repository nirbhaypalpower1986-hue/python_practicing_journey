a = int(input("Enter the number of which you want table: "))

for i in range(1,11):
    print(f"{a}*{i}={a*i}")
    