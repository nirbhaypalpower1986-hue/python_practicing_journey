a = int(input("Enter the number: "))
i = 1

while(i<11):
    print(f"{a}*{i}={a*i}")
    i += 1