'''
 Write a program to print the following star pattern.
  *
 ***
*****
'''
n = int(input("Enter the nmber of rows: "))

i = 1
if (n<=0):
    print("It's not possible. To build this pattern with these number.")
else:    
    for i in range(i,n+1):
        print(" "*(n-i),end="")
        print(("*")*((2*i)-1))
