n = int(input("Enter the number of which you want table of: "))

# s = []

for i in range(1,11):
    b=(f"{n}x{11-i}={n*(11-i)}")
    print(b)
    
#     s.append(b)
# s.reverse()
# print(s) 