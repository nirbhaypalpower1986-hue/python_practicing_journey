'''
Write a program to print the following star pattern.
* * *
*   *
* * * for n = 3
'''

n = int(input("Enter the number of rows(should be greater or equal to 3): "))

i = 0
print("*"*n)
for i in range(i,(n-2)):
    print(f"*{" "*5
              (n-2)}*")
print("*"*n)    


