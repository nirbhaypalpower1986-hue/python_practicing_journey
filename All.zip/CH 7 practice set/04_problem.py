n=int(input("Enter the number: "))

i = 2
while(i<(n)):

    if ((n%i) == 0):
        print("it is not a prime number.")
        break
    i+=1
        
else:
    print("it is a prime number.")     
        
# for b in range(2,n):
#     if n%b== 0:
#         print("The number is not prime.")  
#         break
# else:
    print("The number is not prime.")    
