l = ["Abhay", "Nirbhay", "Ritesh","Suresh","Durgesh Nai","Akash"]
for i in l:
    if ("A" or "N") in i:# or i.startswith("A")
        print(f"{i}")
      