with open("poem.txt") as f:
    s = f.readline()
    while s!=" ":
        if "twinkle" in s:
            print("Yes twinke is present in poem.txt")
            break