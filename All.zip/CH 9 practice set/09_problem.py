def check(g):
    with open("this.txt","r") as d:
        u = d.read()
        if g==u:
            print("Yes these files are exactly same.Both have same content.")

        else:
            print("No both files are not same. There is somewhere different.")    

with open("log.txt","r") as f:
    a = f.read()
    check(a)