with open("log.txt", "r") as f:
    lines = f.readlines()
    a = 1
    for line in lines:
        if "python" in line:
            print(f"Yes python is present in log.txt at line '{line}'")
            print(f"In line no. {a}")
            break
        a += 1
        
    else:
        print("Python is not present in file.")