def correction(d):
    with open("file.txt","w") as r:
        r.write(d)


with open("file.txt","r") as f:
    c = f.read()
    d = c.replace("Donkey","####")
    correction(d)