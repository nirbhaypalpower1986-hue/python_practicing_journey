a = ["donkey","bad","ugly"]

def enend(g):
    with open("files.txt","w") as i:
        i.write(g)

with open("files.txt","r") as f:
    d=f.read()
    for u in a:
        d = d.replace(u,"####")
        enend(d)
        print(u)
    
