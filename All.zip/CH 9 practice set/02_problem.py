import random
print("You are playing a game.")

score = 0

def game(u):
    score = random.randint(1,10000)
    print(f"The previous high_score is {u}")
    print(f"Your score is {score}")

    with open("High_Score.txt","w") as p:
        if u<score:
            p.write(str(score))
            print("You broke the previous high_score with ",(score-u))
        elif u==score:
            print("You match the previous high_score.")
            p.write(str(score))
        else:
            print("The high_score is ",(u-score)," ahead from you.")
            p.write(str(u))
    

with open("High_Score.txt") as f:
    d=f.readline() 
    if d == "":
        high_score = 0
    else:
        high_score = int(d)
    game(high_score)
