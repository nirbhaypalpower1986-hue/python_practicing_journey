with open("this.txt","w") as i:
    i.write("")