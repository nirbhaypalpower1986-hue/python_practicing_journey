def copy(h):
    with open("this.txt","w") as i:
        i.write(h)
        print("Done")

with open("log.txt", "r") as f:
    a = f.read()
    copy(a)