with open("log.txt","r") as f:
    c = f.read()
    if "python" in c:
        print("python is present in the file.")
    else:
        print("python is not present in the file.")