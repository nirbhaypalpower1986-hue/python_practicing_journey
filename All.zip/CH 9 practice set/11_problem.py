with open("sample.txt","r") as f:
    a = f.read()

with open("renamed_by_python.txt","w") as d:
    d.write(a)    

#for real, this is most suitable method
#like open the file which you want to rename
#then copy to the file of new name which you want
#and then delete the old file

#but for deleting the old file we have to use "OS" or "SHUT" module