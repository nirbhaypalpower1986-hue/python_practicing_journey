def Table(b):
    with open(f"Tables/table_{b}.txt","w") as f:
        for i in range(1,11):
            f.write(f"{b} x {i} = {b*i}\n")

for b in range(2,21):
    Table(b)



          