for i in range(4): # from 0 to 3 like in strings

    print(i)
# or like this 

for a in range(1,50,4):# from 1 to 50 and skip value of 4
    print(a)