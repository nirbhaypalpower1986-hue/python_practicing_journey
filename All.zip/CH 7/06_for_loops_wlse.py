a=[ 1,"Abhay",34,45]

for i in a:
    print(i)

else:               # when for loop ends then this condition applies
    print("Done")