l = [1, "Abhay",True,"This","Rohan","Nirbhay","Ritesh"]

i = 0 

while(i<len(l)):
    print(l[i])
    i+=1
