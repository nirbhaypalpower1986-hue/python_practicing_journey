i = 1

while(i<6):# it execute the operation until the condition did't match
    print(i)
    i += 1 # i = i+1

'''
output
1
2
3 
4
5
'''