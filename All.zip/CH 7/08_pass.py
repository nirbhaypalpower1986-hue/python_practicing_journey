for i in range(100):# MEANS  i pass this program for doing later  
    pass                # mai isme bad me kam karunga aur ye error na de isilye mai isme pass likha


i = 0
while i < 12:
    print(i)
    i += 1       


