l=[1, "Abhay",True,"This","Rohan","Nirbhay","Ritesh"]

for i in l:
    print(i)

# t = (1,5.6,76,76,98,9)
# for i in t:
#     print(i)

# s = "Abhay"
# for i in s:
#     print(i)

