for i in range(100):
    if i == 34:# exit the loop right now
        break
    print(i)


for i in range(40):
    if i == 16:
        continue# skip this value or iteration
    print(i)        