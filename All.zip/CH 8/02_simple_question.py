def gd():
    a = input("enter the name: ")
    print(f"Good morning {a}.")
gd()


