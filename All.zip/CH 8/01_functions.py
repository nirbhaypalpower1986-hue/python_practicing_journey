# a = int(input("Enter the number: "))
# b = int(input("Enter the number: "))
# c = int(input("Enter the number: ")) 


# average = (a+b+c)/3
# print(average) 

# a = int(input("Enter the number: "))
# b = int(input("Enter the number: "))
# c = int(input("Enter the number: "))

# average = (a+b+c)/3
# print(average) 
                                # print is also a function, that is build in fuction

# how many i do that so i 
# have to make a function to make my work easy  
#if the command is repitable

def avg():
    a = int(input("Enter the number: "))
    b = int(input("Enter the number: "))
    c = int(input("Enter the number: "))

    average=(a+b+c)/3
    print(average)
    return average

a=avg()#funtion call
print(a) # this will print the value of average because the 
# function avg() returns the value of average and given to a 
print("Thanks!")    
avg()   
print("Thanks!")   
avg()    
print("Thanks!")  
avg()  # if i had to do this multiple times  
avg()    
    



