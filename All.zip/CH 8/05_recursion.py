'''
factorial (n) = n * (n-1) * (n-2)*.....3*2*1
factorial (n) = n * factorial(n-1)
'''

n = int(input("Enter the number: "))
def factorial(n):
    if n == 1 or n == 0:
        return 1
    else:
        return n*factorial(n-1)
# how this work lets figure out, here 
# due to recursion the function will call
# itself until it reach the base case,
# which is n==1 or n==0, then it will 
# return 1 and then the function will
# return the value of n*factorial(n-1) 
# until it reach the first call of the 
# function.
print(factorial(n))

