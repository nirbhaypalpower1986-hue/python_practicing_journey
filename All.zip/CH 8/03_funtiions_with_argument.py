def gd(name,ending): # these variables contains values
    print(f"Good morning {name}.")
    print(ending)
    return "ok" # this will return the value "ok" to the variable a
gd("Abhay","Thanks!") # these are the values
gd("Akash","thank you")

a = gd("maya","Goodbye!") # here a can't get any value because 
# the function gd() doesn't return anything, it only prints values.

print(a)# this will print "ok" because the function gd()
# returns the value "ok"
