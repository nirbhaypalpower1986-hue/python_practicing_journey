def gd(name,ending="Goodbye!"): # here ending has a a by default value
    #of "Goodbye!" if no value is provided for ending
    print(f"Good morning {name}.")
    print(ending)
# if i 
gd("Abhay")# here ending has assign Goodbye! value
gd("Akash","Thank you!")# here ending has assign Thank you! value





