a = "Abhay is a good boy, and  he loves to play MINECRAFT"#parent string
print(a.replace("  ","   "))# replace double space with three single space if double space present in parent string