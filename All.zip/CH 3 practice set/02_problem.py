Letter = '''        Dear |Name|,
            you are selected !
        |Date|'''

print(Letter.replace("|Name|","Abhay").replace("|Date|","21st june 2026"))