a = "Dear Abhay,\n\t You  are learning python is good.\n!Thanks"
print(a)