a = "Abhay is a good boy, and  he loves to play MINECRAFT"
print(a.find("  "))# double space at index 25 so it prints number 25 or if double space don't be in the string then it prints -1